function saveTodo() {
    // read the text from the input field
    let text = $("#txtTodo").val();

    if (text.length == 0) {
        alert("Error: you must type something");
        return; // get out of the function, do not continue
    }
    let syntax = "<div class='todo-item'>" + text + " <button class=' btn tbn-sm btn-danger' > Delete </button> </div>";
    $("#todoContainer").append(syntax);
    //    clear method
    $("#txtTodo").val('');
    $("#txtTodo").focus();
   
}



function init() {
    //   load data 
    
    // hook events
    
    $("#btnSave").click(saveTodo);
    $("#txtTodo").keypress(function (args) {
        if (args.key == "Enter") {
            saveTodo();          
        }
    });
    
    
    $("#todoContainer").on('click', '.btn-danger', function(){
        console.log("removing item");
        $(this).parent().remove(); 
    });




}






window.onload = init;